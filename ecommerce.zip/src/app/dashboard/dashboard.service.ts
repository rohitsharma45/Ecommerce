import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  private dashboardUrl: string;

  constructor(private http: HttpClient) {
 this.dashboardUrl="http://localhost:9080";
   }


   public getAllItems() : Observable<any>{
    return this.http.get<any>(this.dashboardUrl+"/getAllItems()");
  }
}
