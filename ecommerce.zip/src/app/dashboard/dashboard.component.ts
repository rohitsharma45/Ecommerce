import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DashboardService } from './dashboard.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  items: any;

  constructor(private router: Router,private dashboardService: DashboardService) { }

  ngOnInit(): void {
    this.dashboardService.getAllItems().subscribe(data => {
      this.items = data;
      console.info(data);
    });
  }

  loadGroceries(): void{
    this.router.navigateByUrl("groceries");
  }
  loadElectronics(): void{
    this.router.navigateByUrl("electronics");
  }
  loadClothing(): void{
    this.router.navigateByUrl("clothing");
  }
  loadFurniture(): void{
    this.router.navigateByUrl("furniture");
  }
  loadPersonalCare(): void{
    this.router.navigateByUrl("personalcare");
  }
}
