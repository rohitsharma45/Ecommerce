import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CartComponent } from './cart/cart.component';
import { ClothingComponent } from './clothing/clothing.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ElectronicsComponent } from './electronics/electronics.component';
import { FurnitureComponent } from './furniture/furniture.component';
import { GroceriesComponent } from './groceries/groceries.component';
import { LoginComponent } from './login/login.component';
import { PersonalcareComponent } from './personalcare/personalcare.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent},
  { path: 'groceries', component: GroceriesComponent},
  { path: 'electronics', component: ElectronicsComponent},
  { path: 'clothing', component: ClothingComponent},
  { path: 'furniture', component: FurnitureComponent},
  { path: 'personalcare', component: PersonalcareComponent},
  { path: 'cart', component: CartComponent},
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
