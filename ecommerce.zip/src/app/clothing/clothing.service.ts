import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ClothingService {

  private clothingUrl: string;
  constructor(private http: HttpClient) { 
    this.clothingUrl="http://localhost:9080"
  }

  public getClothingDetails() : Observable<any>{
    return this.http.get<any>(this.clothingUrl+"/getClothingDetails");
  }


}
