import { Component, OnInit } from '@angular/core';
import { ClothingService } from './clothing.service';

@Component({
  selector: 'app-clothing',
  templateUrl: './clothing.component.html',
  styleUrls: ['./clothing.component.css']
})
export class ClothingComponent implements OnInit {

  clothing : any;

  constructor(private clothingService: ClothingService) { }

  ngOnInit(): void {
    this.clothingService.getClothingDetails().subscribe(data => {
      this.clothing = data;
      console.info(data);
    });
  }
  }
