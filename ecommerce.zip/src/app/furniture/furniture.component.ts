import { Component, OnInit } from '@angular/core';
import { FurnitureService } from './furniture.service';


@Component({
  selector: 'app-furniture',
  templateUrl: './furniture.component.html',
  styleUrls: ['./furniture.component.css']
})
export class FurnitureComponent implements OnInit {

  furniture : any;

  constructor(private furnitureService: FurnitureService) { }

  ngOnInit(): void {
    this.furnitureService.getAllDetails().subscribe(data => {
      this.furniture = data;
      console.info(data);
    });
  }
}
