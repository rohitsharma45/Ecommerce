import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FurnitureService {

  private furnitureUrl: string;
  constructor(private http: HttpClient) { 
    this.furnitureUrl="http://localhost:9080"
  }

  public getAllDetails() : Observable<any>{
    return this.http.get<any>(this.furnitureUrl+"/getFurnitureDetails");
  }


}
