import { style } from '@angular/animations';
import { Component, ElementRef, OnInit } from '@angular/core';

@Component({
  selector: 'menubar',
  templateUrl: './menubar.component.html',
  styleUrls: ['./menubar.component.css']
})
export class MenubarComponent implements OnInit {

  constructor(private elementRef: ElementRef) { }

  ngOnInit(): void {
  }

 open(){
   console.info("opening sidebar");
   //document.getElementById('sidebar')?.style.display=true;
  //this.elementRef.nativeElement.getElementById.style.display='block';
  const sidebar=document.getElementById('sidebar');
  if(sidebar!== null){
    sidebar.style.display="block";
  }
   
 // element.style.display="block";
 }

 close(){
   console.log("closing sidebar");
 // element.style.display="none";
 const sidebar=document.getElementById('sidebar');
  if(sidebar!== null){
    sidebar.style.display="none";
  }
 }

}
