import { style } from '@angular/animations';
import { Component, ElementRef, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menubar',
  templateUrl: './menubar.component.html',
  styleUrls: ['./menubar.component.css']
})
export class MenubarComponent implements OnInit {

  constructor(private elementRef: ElementRef,private router: Router) {  }

  ngOnInit(): void {
  }

 open(){
   console.info("opening sidebar");
   //document.getElementById('sidebar')?.style.display=true;
  //this.elementRef.nativeElement.getElementById.style.display='block';
  const sidebar=document.getElementById('sidebar');
  if(sidebar!== null){
    sidebar.style.display="block";
  }
   
 // element.style.display="block";
 }

 close(){
   console.log("closing sidebar");
 // element.style.display="none";
 const sidebar=document.getElementById('sidebar');
  if(sidebar!== null){
    sidebar.style.display="none";
  }
 }

 opencart(): void{
  console.log("Inside open cart");
  this.router.navigateByUrl("cart");
}

}
