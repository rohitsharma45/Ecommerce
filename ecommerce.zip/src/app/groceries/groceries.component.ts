import { Component, OnInit } from '@angular/core';
import { GroceriesService } from './groceries.service';

@Component({
  selector: 'app-groceries',
  templateUrl: './groceries.component.html',
  styleUrls: ['./groceries.component.css']
})
export class GroceriesComponent implements OnInit {

  groceries : any;

  constructor(private groceriesService: GroceriesService) { }

  ngOnInit(): void {
    this.groceriesService.getAllDetails().subscribe(data => {
      this.groceries = data;
      console.info(data);
    });
  }
  }


