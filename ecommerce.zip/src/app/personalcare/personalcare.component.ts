import { Component, OnInit } from '@angular/core';
import { PersonalcareService } from './personalcare.service';

@Component({
  selector: 'app-personalcare',
  templateUrl: './personalcare.component.html',
  styleUrls: ['./personalcare.component.css']
})
export class PersonalcareComponent implements OnInit {

  personalcare : any;

  constructor(private personalcareService: PersonalcareService) { }

  ngOnInit(): void {
    this.personalcareService.getAllDetails().subscribe(data => {
      this.personalcare = data;
      console.info(data);
    });
  }
}
