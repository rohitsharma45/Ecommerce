import { TestBed } from '@angular/core/testing';

import { PersonalcareService } from './personalcare.service';

describe('GroceriesService', () => {
  let service: PersonalcareService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PersonalcareService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
